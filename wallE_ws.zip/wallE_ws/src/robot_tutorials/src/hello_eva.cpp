#include<iostream>

int main()
{
	std::cout<<"Wall-E: Hello Eva!\n";
	return 0;
}
